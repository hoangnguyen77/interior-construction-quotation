package com.swp.spring.interiorconstructionquotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InteriorConstructionQuotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
